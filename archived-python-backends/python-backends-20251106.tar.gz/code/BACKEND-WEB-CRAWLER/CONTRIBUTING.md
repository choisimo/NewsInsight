Contributing is always welcome!

I am no professional flask developer, if you know a better way that something can be done, please let me know!

Otherwise, it's always best to PR into the `master` branch.

Please be sure that all new functionality has a matching test!

Use `pytest` to validate/test, you can run the existing tests as `pytest tests/test_notification.py` for example
