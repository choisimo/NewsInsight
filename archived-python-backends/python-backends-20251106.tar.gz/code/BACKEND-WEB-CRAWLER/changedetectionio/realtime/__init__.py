"""
Socket.IO realtime updates module for changedetection.io
"""